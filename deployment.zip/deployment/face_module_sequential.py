import cv2
from deepface import DeepFace
import numpy as np
from facial_landmarking_utils import face_pose

face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")

def numoffaces(image):
    grey = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(grey, scaleFactor=1.2, minNeighbors=4, minSize=(40, 40))
    return len(faces)

def enhance_frame(image):
    alpha = 1.3
    beta = 30
    image = cv2.convertScaleAbs(image, alpha = alpha, beta=beta)
    kernel = np.array([[0, -1, 0],
                   [-1, 5,-1],
                   [0, -1, 0]])
    new = cv2.filter2D(src=image, ddepth=-1, kernel=kernel)
    return new

def face_module(frame_path, target_path):
    '''
    Takes location as input of current frame from camera and the location of target image, and returns the output
    '''
    frame = cv2.imread(frame_path)
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    frame = cv2.flip(frame, 1)
    frame = enhance_frame(frame)

    target = cv2.imread(target_path)
    target = cv2.cvtColor(target, cv2.COLOR_BGR2RGB)

    outcome = DeepFace.verify(img1_path=target, img2_path=frame, model_name='ArcFace', detector_backend='mediapipe', normalization='ArcFace', align=False)['verified']
    num_faces = numoffaces(frame)
    face_dict = face_pose(frame)

    output = {}
    output['Identity'] = outcome
    output['Number of people'] = num_faces
    output['Face Direction'] = face_dict['dir_text']
    output['Face Zone'] = face_dict['colour_zone']
    output['Eye Direction'] = face_dict['iris_pos']
    output['Mouth'] = face_dict['mouth_zone']
    return output

def start(frame_path, target_path):
    frame = cv2.imread(frame_path)
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    frame = cv2.flip(frame, 1)
    frame = enhance_frame(frame)

    target = cv2.imread(target_path)
    target = cv2.cvtColor(target, cv2.COLOR_BGR2RGB)

    outcome = DeepFace.verify(img1_path=target, img2_path=frame, model_name='ArcFace', detector_backend='mediapipe', normalization='ArcFace', align=False)['verified']
    
    if outcome:
        cv2.imwrite(target_path, frame) ## this will be new target.png which will be tested
    
    return outcome